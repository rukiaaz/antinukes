import mongoose from 'mongoose';
import { CONFIG } from './config';

let connected = false;

export async function connectDatabase(): Promise<void> {
  if (connected) return;

  try {
    await mongoose.connect(CONFIG.MONGODB_URI);
    connected = true;
  } catch (error) {
    console.error('[Repent] Database connection failed:', error);
    throw error;
  }
}

export function isConnected(): boolean {
  return connected && mongoose.connection.readyState === 1;
}
