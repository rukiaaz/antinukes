import mongoose, { Schema } from 'mongoose';
import type { BackupData } from '../types';

const PermissionOverwriteSchema = new Schema({
  id: { type: String, required: true },
  type: { type: Number, required: true },
  allow: { type: String, required: true },
  deny: { type: String, required: true },
}, { _id: false });

const ChannelBackupSchema = new Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  type: { type: Number, required: true },
  parentId: { type: String, default: null },
  position: { type: Number, required: true },
  permissionOverwrites: { type: [PermissionOverwriteSchema], default: [] },
  topic: { type: String, default: null },
  nsfw: { type: Boolean, default: false },
  rateLimitPerUser: { type: Number, default: 0 },
  bitrate: { type: Number, default: undefined },
  userLimit: { type: Number, default: undefined },
}, { _id: false });

const CategoryBackupSchema = new Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  position: { type: Number, required: true },
  permissionOverwrites: { type: [PermissionOverwriteSchema], default: [] },
}, { _id: false });

const RoleBackupSchema = new Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  color: { type: Number, default: 0 },
  hoist: { type: Boolean, default: false },
  icon: { type: String, default: null },
  unicodeEmoji: { type: String, default: null },
  position: { type: Number, required: true },
  permissions: { type: String, required: true },
  mentionable: { type: Boolean, default: false },
}, { _id: false });

const WebhookBackupSchema = new Schema({
  id: { type: String, required: true },
  channelId: { type: String, required: true },
  name: { type: String, required: true },
  avatar: { type: String, default: null },
  token: { type: String, default: null },
}, { _id: false });

const EmojiBackupSchema = new Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  animated: { type: Boolean, default: false },
  url: { type: String, required: true },
}, { _id: false });

const StickerBackupSchema = new Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  description: { type: String, default: null },
  tags: { type: String, default: '' },
  type: { type: Number, required: true },
  formatType: { type: Number, required: true },
  url: { type: String, required: true },
}, { _id: false });

const ServerSettingsBackupSchema = new Schema({
  name: { type: String, required: true },
  icon: { type: String, default: null },
  banner: { type: String, default: null },
  description: { type: String, default: null },
  verificationLevel: { type: Number, default: null },
  defaultMessageNotifications: { type: Number, default: null },
  explicitContentFilter: { type: Number, default: null },
  systemChannelId: { type: String, default: null },
  systemChannelFlags: { type: Number, default: 0 },
  rulesChannelId: { type: String, default: null },
  publicUpdatesChannelId: { type: String, default: null },
  preferredLocale: { type: String, default: 'en-US' },
  afkChannelId: { type: String, default: null },
  afkTimeout: { type: Number, default: 300 },
}, { _id: false });

const BackupSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  channels: { type: [ChannelBackupSchema], default: [] },
  categories: { type: [CategoryBackupSchema], default: [] },
  roles: { type: [RoleBackupSchema], default: [] },
  webhooks: { type: [WebhookBackupSchema], default: [] },
  emojis: { type: [EmojiBackupSchema], default: [] },
  stickers: { type: [StickerBackupSchema], default: [] },
  serverSettings: { type: ServerSettingsBackupSchema, default: null },
  timestamp: { type: Date, default: Date.now },
}, {
  timestamps: true,
});

BackupSchema.index({ guildId: 1, timestamp: -1 });

export const Backup = mongoose.model('Backup', BackupSchema);

export async function saveBackup(guildId: string, data: BackupData): Promise<void> {
  const count = await Backup.countDocuments({ guildId }).exec();
  if (count >= 5) {
    const oldest = await Backup.findOne({ guildId }).sort({ timestamp: 1 }).exec();
    if (oldest) await oldest.deleteOne();
  }
  await Backup.create({ guildId, ...data });
}

export async function getLatestBackup(guildId: string): Promise<BackupData | null> {
  const doc = await Backup.findOne({ guildId }).sort({ timestamp: -1 }).lean().exec();
  return doc as unknown as BackupData | null;
}

export async function deleteBackups(guildId: string): Promise<void> {
  await Backup.deleteMany({ guildId }).exec();
}
