import mongoose, { Schema } from 'mongoose';
import type { GuildConfig, ActionType, ProtectionConfig } from '../types';
import { DEFAULT_PROTECTIONS } from '../utils/config';

const ProtectionConfigSchema = new Schema<ProtectionConfig>({
  enabled: { type: Boolean, required: true, default: true },
  threshold: { type: Number, required: true, min: 1, max: 100 },
  windowSeconds: { type: Number, required: true, min: 1, max: 3600 },
  punishment: { type: String, enum: ['ban', 'kick', 'timeout', 'removeRoles'], required: true },
  timeoutDuration: { type: Number, default: 3600 },
}, { _id: false });

interface IGuildSettings {
  guildId: string;
  logChannelId: string | null;
  ownerId: string;
  protections: Map<string, ProtectionConfig>;
  whitelistUsers: string[];
  whitelistRoles: string[];
  panicMode: boolean;
  lockdownChannels: string[];
  setup: boolean;
}

const GuildSettingsSchema = new Schema<IGuildSettings>({
  guildId: { type: String, required: true, unique: true, index: true },
  logChannelId: { type: String, default: null },
  ownerId: { type: String, required: true },
  protections: {
    type: Map,
    of: ProtectionConfigSchema,
    default: new Map(Object.entries(DEFAULT_PROTECTIONS)),
  },
  whitelistUsers: { type: [String], default: [] },
  whitelistRoles: { type: [String], default: [] },
  panicMode: { type: Boolean, default: false },
  lockdownChannels: { type: [String], default: [] },
  setup: { type: Boolean, default: false },
}, {
  timestamps: true,
  minimize: false,
});

GuildSettingsSchema.pre('save', function (this: mongoose.Document & IGuildSettings, next) {
  if (!this.protections || this.protections.size === 0) {
    this.protections = new Map(Object.entries(DEFAULT_PROTECTIONS));
  }
  next();
});

const GuildSettingsModel = mongoose.model<IGuildSettings>('GuildSettings', GuildSettingsSchema);

function docToConfig(doc: IGuildSettings | null): GuildConfig | null {
  if (!doc) return null;
  const protections: Record<string, ProtectionConfig> = {};
  const protMap = doc.protections;
  if (protMap) {
    if (protMap instanceof Map) {
      for (const [k, v] of protMap.entries()) {
        protections[k] = v as ProtectionConfig;
      }
    } else if (typeof protMap === 'object') {
      for (const [k, v] of Object.entries(protMap)) {
        protections[k] = v as ProtectionConfig;
      }
    }
  }
  return {
    guildId: doc.guildId,
    logChannelId: doc.logChannelId,
    ownerId: doc.ownerId,
    protections: protections as Record<ActionType, ProtectionConfig>,
    whitelistUsers: doc.whitelistUsers ?? [],
    whitelistRoles: doc.whitelistRoles ?? [],
    panicMode: doc.panicMode ?? false,
    lockdownChannels: doc.lockdownChannels ?? [],
    setup: doc.setup ?? false,
  };
}

export async function getGuildConfig(guildId: string): Promise<GuildConfig | null> {
  const doc = await GuildSettingsModel.findOne({ guildId }).lean().exec() as unknown as IGuildSettings | null;
  return docToConfig(doc);
}

export async function createGuildConfig(guildId: string, ownerId: string): Promise<GuildConfig> {
  const existing = await GuildSettingsModel.findOne({ guildId }).exec();
  if (existing) {
    const cfg = docToConfig(existing.toObject());
    if (!cfg) throw new Error('Failed to parse existing config');
    return cfg;
  }

  const config = new GuildSettingsModel({
    guildId,
    ownerId,
    protections: new Map(Object.entries(DEFAULT_PROTECTIONS)),
  });
  await config.save();
  const cfg = docToConfig(config.toObject());
  if (!cfg) throw new Error('Failed to parse new config');
  return cfg;
}

export async function updateGuildConfig(
  guildId: string,
  update: Partial<GuildConfig>
): Promise<GuildConfig | null> {
  const doc = await GuildSettingsModel.findOneAndUpdate({ guildId }, update, { new: true }).lean().exec();
  return docToConfig(doc as unknown as IGuildSettings | null);
}

export async function getProtectionConfig(
  guildId: string,
  actionType: ActionType
): Promise<ProtectionConfig | null> {
  const config = await GuildSettingsModel.findOne({ guildId }).exec();
  if (!config) return null;
  const prot = config.protections.get(actionType);
  return prot ?? null;
}

export async function setProtectionConfig(
  guildId: string,
  actionType: ActionType,
  protection: Partial<ProtectionConfig>
): Promise<boolean> {
  const config = await GuildSettingsModel.findOne({ guildId }).exec();
  if (!config) return false;

  const existing = config.protections.get(actionType) ?? { ...DEFAULT_PROTECTIONS[actionType] };
  config.protections.set(actionType, { ...existing, ...protection });
  await config.save();
  return true;
}

export async function addWhitelistUser(guildId: string, userId: string): Promise<boolean> {
  const result = await GuildSettingsModel.updateOne(
    { guildId },
    { $addToSet: { whitelistUsers: userId } }
  ).exec();
  return result.modifiedCount > 0;
}

export async function removeWhitelistUser(guildId: string, userId: string): Promise<boolean> {
  const result = await GuildSettingsModel.updateOne(
    { guildId },
    { $pull: { whitelistUsers: userId } }
  ).exec();
  return result.modifiedCount > 0;
}

export async function addWhitelistRole(guildId: string, roleId: string): Promise<boolean> {
  const result = await GuildSettingsModel.updateOne(
    { guildId },
    { $addToSet: { whitelistRoles: roleId } }
  ).exec();
  return result.modifiedCount > 0;
}

export async function removeWhitelistRole(guildId: string, roleId: string): Promise<boolean> {
  const result = await GuildSettingsModel.updateOne(
    { guildId },
    { $pull: { whitelistRoles: roleId } }
  ).exec();
  return result.modifiedCount > 0;
}

export async function setPanicMode(guildId: string, enabled: boolean): Promise<boolean> {
  const result = await GuildSettingsModel.updateOne(
    { guildId },
    { $set: { panicMode: enabled } }
  ).exec();
  return result.modifiedCount > 0 || result.matchedCount > 0;
}

export async function isUserWhitelisted(guildId: string, userId: string, roleIds: string[]): Promise<boolean> {
  const doc = await GuildSettingsModel.findOne({ guildId }).lean().exec() as unknown as IGuildSettings | null;
  if (!doc) return false;
  if (doc.whitelistUsers.includes(userId)) return true;
  return roleIds.some(rid => doc.whitelistRoles.includes(rid));
}
