"""
Repent - Utility Commands
Userinfo, serverinfo, ping, afk, avatar, and more.
"""

import time
import discord
from discord.ext import commands
from datetime import datetime

from config import BOT_NAME, VERSION, OWNER_ID, COLOR_INFO, COLOR_SUCCESS
from database import set_afk, get_afk, remove_afk
from utils.embeds import info_embed, success_embed, error_embed


class Utility(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.start_time = datetime.utcnow()

    @discord.app_commands.command(name="userinfo", description="Show info about a user")
    @discord.app_commands.describe(user="User to check (default: yourself)")
    async def userinfo(self, interaction: discord.Interaction, user: discord.Member = None):
        target = user or interaction.user
        roles = [r.mention for r in target.roles if r.name != "@everyone"][:10]
        join_pos = sorted(interaction.guild.members, key=lambda m: m.joined_at or datetime.utcnow()).index(target) + 1

        embed = discord.Embed(
            title=f"👤 {target.display_name}",
            color=target.color if target.color.value else COLOR_INFO,
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="Username", value=f"{target.name}\n`{target.id}`", inline=True)
        embed.add_field(name="Nickname", value=target.nick or "None", inline=True)
        embed.add_field(name="Bot", value="Yes" if target.bot else "No", inline=True)
        embed.add_field(name="Joined", value=f"<t:{int(target.joined_at.timestamp())}:F>\n(<t:{int(target.joined_at.timestamp())}:R>)" if target.joined_at else "N/A", inline=False)
        embed.add_field(name="Created", value=f"<t:{int(target.created_at.timestamp())}:F>\n(<t:{int(target.created_at.timestamp())}:R>)", inline=False)
        embed.add_field(name=f"Roles ({len(target.roles) - 1})", value=" ".join(roles) if roles else "None", inline=False)
        embed.add_field(name="Join Position", value=f"#{join_pos}", inline=True)
        embed.add_field(name="Top Role", value=target.top_role.mention, inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=False)

    @discord.app_commands.command(name="serverinfo", description="Show server information")
    async def serverinfo(self, interaction: discord.Interaction):
        guild = interaction.guild
        owner = guild.get_member(guild.owner_id) or await self.bot.fetch_user(guild.owner_id)

        total = guild.member_count
        humans = sum(1 for m in guild.members if not m.bot)
        bots = total - humans if total else 0

        embed = discord.Embed(
            title=f"🏠 {guild.name}",
            color=COLOR_INFO,
        )
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Owner", value=f"{owner.mention}\n`{guild.owner_id}`", inline=True)
        embed.add_field(name="Members", value=f"**{total}** total\n{humans} humans / {bots} bots", inline=True)
        embed.add_field(name="Boost", value=f"Level {guild.premium_tier}\n{guild.premium_subscription_count} boosts", inline=True)
        embed.add_field(name="Channels", value=f"{len(guild.text_channels)} text / {len(guild.voice_channels)} voice / {len(guild.categories)} categories", inline=True)
        embed.add_field(name="Roles", value=str(len(guild.roles)), inline=True)
        embed.add_field(name="Emojis", value=str(len(guild.emojis)), inline=True)
        embed.add_field(name="Created", value=f"<t:{int(guild.created_at.timestamp())}:F>\n(<t:{int(guild.created_at.timestamp())}:R>)", inline=False)
        embed.add_field(name="ID", value=f"`{guild.id}`", inline=False)
        if guild.vanity_url_code:
            embed.add_field(name="Vanity", value=f"discord.gg/{guild.vanity_url_code}", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=False)

    @discord.app_commands.command(name="avatar", description="Show a user's avatar")
    @discord.app_commands.describe(user="User (default: yourself)")
    async def avatar(self, interaction: discord.Interaction, user: discord.Member = None):
        target = user or interaction.user
        embed = discord.Embed(
            title=f"🖼️ {target.display_name}'s Avatar",
            color=COLOR_INFO,
        )
        embed.set_image(url=target.display_avatar.url)
        await interaction.response.send_message(embed=embed, ephemeral=False)

    @discord.app_commands.command(name="roleinfo", description="Show info about a role")
    @discord.app_commands.describe(role="Role to inspect")
    async def roleinfo(self, interaction: discord.Interaction, role: discord.Role):
        members = len(role.members)
        color = role.color if role.color.value else COLOR_INFO
        embed = discord.Embed(
            title=f"📛 {role.name}",
            color=color,
        )
        embed.add_field(name="ID", value=f"`{role.id}`", inline=True)
        embed.add_field(name="Color", value=str(role.color), inline=True)
        embed.add_field(name="Members", value=str(members), inline=True)
        embed.add_field(name="Position", value=str(role.position), inline=True)
        embed.add_field(name="Hoist", value="Yes" if role.hoist else "No", inline=True)
        embed.add_field(name="Mentionable", value="Yes" if role.mentionable else "No", inline=True)
        embed.add_field(name="Created", value=f"<t:{int(role.created_at.timestamp())}:R>", inline=False)
        embed.add_field(name="Permissions", value=f"```\n{role.permissions.value}\n```", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=False)

    @discord.app_commands.command(name="channelinfo", description="Show channel info")
    @discord.app_commands.describe(channel="Channel (default: current)")
    async def channelinfo(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        ch = channel or interaction.channel
        embed = discord.Embed(
            title=f"#️⃣ {ch.name}",
            color=COLOR_INFO,
        )
        embed.add_field(name="ID", value=f"`{ch.id}`", inline=True)
        embed.add_field(name="Type", value=str(ch.type), inline=True)
        embed.add_field(name="NSFW", value="Yes" if ch.nsfw else "No", inline=True)
        embed.add_field(name="Slowmode", value=f"{ch.slowmode_delay}s" if ch.slowmode_delay else "None", inline=True)
        embed.add_field(name="Category", value=ch.category.name if ch.category else "None", inline=True)
        embed.add_field(name="Position", value=str(ch.position), inline=True)
        embed.add_field(name="Created", value=f"<t:{int(ch.created_at.timestamp())}:R>", inline=False)
        if ch.topic:
            embed.add_field(name="Topic", value=ch.topic[:500], inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=False)

    @discord.app_commands.command(name="ping", description="Check bot latency")
    async def ping(self, interaction: discord.Interaction):
        ws_latency = round(self.bot.latency * 1000)
        start = time.perf_counter()
        await interaction.response.send_message("Testing...", ephemeral=True)
        end = time.perf_counter()
        api_latency = round((end - start) * 1000)

        embed = discord.Embed(
            title="🏓 Pong!",
            color=COLOR_SUCCESS,
        )
        embed.add_field(name="WebSocket", value=f"`{ws_latency}ms`", inline=True)
        embed.add_field(name="API", value=f"`{api_latency}ms`", inline=True)
        await interaction.edit_original_response(embed=embed)

    @discord.app_commands.command(name="uptime", description="Show bot uptime")
    async def uptime(self, interaction: discord.Interaction):
        delta = datetime.utcnow() - self.start_time
        days = delta.days
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        uptime_str = f"{days}d {hours}h {minutes}m {seconds}s"

        embed = discord.Embed(
            title="⏱️ Uptime",
            description=f"**{uptime_str}**",
            color=COLOR_INFO,
        )
        embed.add_field(name="Started", value=f"<t:{int(self.start_time.timestamp())}:F>", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=False)

    @discord.app_commands.command(name="afk", description="Set your AFK status")
    @discord.app_commands.describe(reason="AFK reason")
    async def afk(self, interaction: discord.Interaction, reason: str = "AFK"):
        await set_afk(interaction.guild.id, interaction.user.id, reason)
        await interaction.response.send_message(
            embed=success_embed("AFK Set", f"{interaction.user.mention} is now AFK: **{reason}**"),
            ephemeral=False,
        )

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        # Check if mentioned user is AFK
        for mention in message.mentions:
            afk_data = await get_afk(message.guild.id, mention.id)
            if afk_data:
                try:
                    await message.reply(
                        f"💤 {mention.mention} is AFK: **{afk_data['reason']}** "
                        f"(since <t:{int(datetime.fromisoformat(afk_data['set_at']).timestamp())}:R>)",
                        delete_after=8,
                    )
                except Exception:
                    pass
        # Remove AFK if user sends a message
        afk_data = await get_afk(message.guild.id, message.author.id)
        if afk_data:
            await remove_afk(message.guild.id, message.author.id)
            try:
                await message.reply(f"👋 Welcome back {message.author.mention}! Your AFK has been removed.", delete_after=5)
            except Exception:
                pass

    @discord.app_commands.command(name="botinfo", description="Show bot information")
    async def botinfo(self, interaction: discord.Interaction):
        total_guilds = len(self.bot.guilds)
        total_users = sum(g.member_count for g in self.bot.guilds)
        commands_count = len(self.bot.tree.get_commands())

        embed = discord.Embed(
            title=f"🤖 {BOT_NAME}",
            description=f"**{BOT_NAME}** v{VERSION} — Advanced antinuke, moderation, and utility bot.",
            color=COLOR_INFO,
        )
        embed.add_field(name="Guilds", value=str(total_guilds), inline=True)
        embed.add_field(name="Users", value=str(total_users), inline=True)
        embed.add_field(name="Commands", value=str(commands_count), inline=True)
        embed.add_field(name="Library", value=f"discord.py {discord.__version__}", inline=True)
        embed.add_field(name="Owner", value=f"<@{OWNER_ID}>", inline=True)
        embed.add_field(name="Uptime", value=f"<t:{int(self.start_time.timestamp())}:R>", inline=True)
        embed.set_footer(text=f"{BOT_NAME} v{VERSION}")
        await interaction.response.send_message(embed=embed, ephemeral=False)

    @discord.app_commands.command(name="invite", description="Get the bot invite link")
    async def invite(self, interaction: discord.Interaction):
        perms = discord.Permissions(8)  # Administrator
        url = discord.utils.oauth_url(self.bot.user.id, permissions=perms)
        embed = discord.Embed(
            title=f"🔗 Invite {BOT_NAME}",
            description=f"[Click here to invite {BOT_NAME}]({url})\n\nRecommended: Administrator permission for full antinuke protection.",
            color=COLOR_SUCCESS,
        )
        await interaction.response.send_message(embed=embed, ephemeral=False)


async def setup(bot: commands.Bot):
    await bot.add_cog(Utility(bot))
