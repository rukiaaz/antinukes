"""
Repent - Antinuke System
Uses on_audit_log_entry_create for ALL detection.
This is impossible to bypass via selfbots or nuke bots.
"""

import asyncio
import json
import discord
from discord.ext import commands
from datetime import datetime, timedelta

from config import OWNER_ID, DEFAULT_PUNISHMENT
from database import (
    add_rate_event, count_rate_events, clear_rate_events,
    add_punished_user, get_whitelist_entry, get_guild,
    get_cached_roles, get_cached_channels,
    remove_punished_user, get_punished_users,
    log_action, get_antinuke_threshold,
)
from utils.embeds import antinuke_embed, success_embed, error_embed, info_embed


class Antinuke(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._lock = asyncio.Lock()

    # ── Helpers ──
    async def _is_whitelisted(self, guild_id: int, user_id: int) -> bool:
        """Owner and bot are always whitelisted. Check DB for others (trust_level >= 2)."""
        if user_id == OWNER_ID:
            return True
        if user_id == self.bot.user.id:
            return True
        entry = await get_whitelist_entry(guild_id, user_id)
        if entry and entry.get("trust_level", 0) >= 2:
            return True
        return False

    async def _is_partial_whitelisted(self, guild_id: int, user_id: int) -> bool:
        """Level 1 = partial (exempt from channel/role limits only). Level 2 = full."""
        if await self._is_whitelisted(guild_id, user_id):
            return True
        entry = await get_whitelist_entry(guild_id, user_id)
        if entry and entry.get("trust_level", 0) >= 1:
            return True
        return False

    async def _apply_punishment(self, guild: discord.Guild, member: discord.Member, punishment: str, reason: str):
        """Apply punishment to the attacker. Fast."""
        try:
            if punishment == "ban":
                await guild.ban(member, reason=reason, delete_message_days=0)
            elif punishment == "kick":
                await guild.kick(member, reason=reason)
            elif punishment == "strip":
                await member.edit(roles=[], reason=reason)
                if member.voice and member.voice.channel:
                    await member.edit(deafen=True, reason=reason)
            elif punishment == "timeout":
                until = datetime.utcnow() + timedelta(days=28)
                await member.timeout(until, reason=reason)
        except discord.Forbidden:
            try:
                owner = guild.get_member(guild.owner_id)
                if owner:
                    await owner.send(
                        f"⚠️ **{guild.name}**: I tried to punish **{member}** (`{member.id}`) "
                        f"for antinuke trigger (`{punishment}`) but I lack permissions."
                    )
            except Exception:
                pass
        except Exception:
            pass

    async def _notify_owner(self, guild: discord.Guild, embed: discord.Embed):
        """Send antinuke alert to the server owner via DM."""
        try:
            owner = guild.get_member(guild.owner_id)
            if owner:
                await owner.send(embed=embed)
        except Exception:
            pass

    async def _log_to_channel(self, guild: discord.Guild, embed: discord.Embed):
        """Log antinuke event to the configured log channel."""
        settings = await get_guild(guild.id)
        log_ch_id = settings.get("log_channel", 0)
        if not log_ch_id:
            return
        ch = guild.get_channel(log_ch_id)
        if ch:
            try:
                await ch.send(embed=embed)
            except Exception:
                pass

    async def _check_threshold(self, guild_id: int, user_id: int, action_type: str) -> bool:
        """Add rate event and check if threshold exceeded. Returns True if violation."""
        max_count, window = await get_antinuke_threshold(guild_id, action_type)
        await add_rate_event(guild_id, user_id, action_type)
        count = await count_rate_events(guild_id, user_id, action_type, window)
        return count > max_count

    async def _handle_violation(self, guild: discord.Guild, user_id: int, action_type: str, target_desc: str = ""):
        """Handle an antinuke threshold violation."""
        async with self._lock:
            if await self._is_whitelisted(guild.id, user_id):
                return

            settings = await get_guild(guild.id)
            if not settings.get("antinuke_enabled", 1):
                return

            member = guild.get_member(user_id)
            if not member:
                try:
                    member = await guild.fetch_member(user_id)
                except Exception:
                    return

            punishment = settings.get("punishment", DEFAULT_PUNISHMENT)

            # Apply punishment
            reason = f"[Repent Antinuke] {action_type} threshold exceeded"
            await self._apply_punishment(guild, member, punishment, reason)
            await add_punished_user(guild.id, user_id, reason, self.bot.user.id, punishment)
            await log_action(guild.id, "antinuke_trigger", user_id, {
                "action_type": action_type,
                "punishment": punishment,
                "target": target_desc,
            })

            # Build alert embed
            embed = antinuke_embed(
                action=action_type,
                target=target_desc or "Server",
                responsible=f"{member.mention} (`{member.id}`)",
                punishment=punishment,
                guild=guild,
            )

            # Notify and log
            await self._notify_owner(guild, embed)
            await self._log_to_channel(guild, embed)

            # Clear rate events so we don't spam
            await clear_rate_events(guild.id, user_id, action_type)

    # ── Audit Log Listeners ──
    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry):
        """Primary antinuke detection via audit log. Impossible to bypass."""
        if not entry.user:
            return
        if entry.user.id == self.bot.user.id:
            return

        guild = entry.guild
        if not guild:
            return

        action = entry.action
        user_id = entry.user.id

        # ── Mass Ban ──
        if action == discord.AuditLogAction.ban:
            target = entry.target
            target_desc = f"{target} (`{target.id}`)" if target else "Unknown"
            violated = await self._check_threshold(guild.id, user_id, "ban")
            if violated:
                await self._handle_violation(guild, user_id, "ban", target_desc)

        # ── Mass Kick ──
        elif action == discord.AuditLogAction.kick:
            target = entry.target
            target_desc = f"{target} (`{target.id}`)" if target else "Unknown"
            violated = await self._check_threshold(guild.id, user_id, "kick")
            if violated:
                await self._handle_violation(guild, user_id, "kick", target_desc)

        # ── Mass Channel Delete ──
        elif action == discord.AuditLogAction.channel_delete:
            if await self._is_partial_whitelisted(guild.id, user_id):
                return
            target = entry.target
            target_desc = f"#{target.name}" if target else "Unknown channel"
            violated = await self._check_threshold(guild.id, user_id, "channel_delete")
            if violated:
                await self._handle_violation(guild, user_id, "channel_delete", target_desc)

        # ── Mass Channel Create ──
        elif action == discord.AuditLogAction.channel_create:
            if await self._is_partial_whitelisted(guild.id, user_id):
                return
            target = entry.target
            target_desc = f"#{target.name}" if target else "Unknown channel"
            violated = await self._check_threshold(guild.id, user_id, "channel_create")
            if violated:
                await self._handle_violation(guild, user_id, "channel_create", target_desc)

        # ── Mass Role Delete ──
        elif action == discord.AuditLogAction.role_delete:
            if await self._is_partial_whitelisted(guild.id, user_id):
                return
            target = entry.target
            target_desc = f"@{target.name}" if target else "Unknown role"
            violated = await self._check_threshold(guild.id, user_id, "role_delete")
            if violated:
                await self._handle_violation(guild, user_id, "role_delete", target_desc)

        # ── Mass Role Create ──
        elif action == discord.AuditLogAction.role_create:
            if await self._is_partial_whitelisted(guild.id, user_id):
                return
            target = entry.target
            target_desc = f"@{target.name}" if target else "Unknown role"
            violated = await self._check_threshold(guild.id, user_id, "role_create")
            if violated:
                await self._handle_violation(guild, user_id, "role_create", target_desc)

        # ── Dangerous Role Update ──
        elif action == discord.AuditLogAction.role_update:
            if await self._is_partial_whitelisted(guild.id, user_id):
                return
            # Check if admin perms were granted via changes
            try:
                if entry.changes:
                    for attr, change in entry.changes:
                        if attr.name == "permissions":
                            before_perms = change.before.value if change.before else 0
                            after_perms = change.after.value if change.after else 0
                            admin_bit = 0x8  # ADMINISTRATOR permission bit
                            if (after_perms & admin_bit) and not (before_perms & admin_bit):
                                target = entry.target
                                target_desc = f"@{target.name} → Administrator granted" if target else "Unknown role"
                                violated = await self._check_threshold(guild.id, user_id, "role_update")
                                if violated:
                                    await self._handle_violation(guild, user_id, "role_update", target_desc)
                                break
            except Exception:
                pass

        # ── Webhook Create ──
        elif action == discord.AuditLogAction.webhook_create:
            target = entry.target
            target_desc = f"Webhook: {target.name}" if target and hasattr(target, 'name') else "Unknown webhook"
            violated = await self._check_threshold(guild.id, user_id, "webhook_create")
            if violated:
                await self._handle_violation(guild, user_id, "webhook_create", target_desc)
            # Always instantly delete rogue webhooks by non-trusted
            if not await self._is_whitelisted(guild.id, user_id):
                try:
                    if target and hasattr(target, 'delete'):
                        await target.delete(reason="[Repent] Unauthorized webhook creation")
                except Exception:
                    pass

        # ── Server Update ──
        elif action == discord.AuditLogAction.guild_update:
            target_desc = "Server settings modified"
            violated = await self._check_threshold(guild.id, user_id, "server_update")
            if violated:
                await self._handle_violation(guild, user_id, "server_update", target_desc)

        # ── Bot Add (via OAuth2) ──
        elif action == discord.AuditLogAction.bot_add:
            if await self._is_whitelisted(guild.id, user_id):
                return
            target = entry.target
            target_desc = f"Bot: {target.name} (`{target.id}`)" if target else "Unknown bot"
            violated = await self._check_threshold(guild.id, user_id, "bot_add")
            if violated:
                await self._handle_violation(guild, user_id, "bot_add", target_desc)
            # Always kick unauthorized bots
            if target and not await self._is_whitelisted(guild.id, user_id):
                try:
                    bot_member = guild.get_member(target.id)
                    if bot_member:
                        await guild.kick(bot_member, reason="[Repent] Unauthorized bot addition")
                except Exception:
                    pass

        # ── Owner Transfer (ALWAYS BLOCKED) ──
        elif action == discord.AuditLogAction.guild_owner_transfer:
            target = entry.target
            target_desc = f"Transfer to {target} (`{target.id}`)" if target else "Unknown"
            await self._handle_violation(guild, user_id, "owner_transfer", target_desc)

    # ── Rollback / Restore Command ──
    @discord.app_commands.command(name="restore", description="Restore deleted channels and roles from cache (Admin only)")
    @discord.app_commands.describe(
        restore_type="What to restore: channels, roles, or all"
    )
    @discord.app_commands.choices(restore_type=[
        discord.app_commands.Choice(name="all", value="all"),
        discord.app_commands.Choice(name="channels", value="channels"),
        discord.app_commands.Choice(name="roles", value="roles"),
    ])
    async def restore(self, interaction: discord.Interaction, restore_type: discord.app_commands.Choice[str] = None):
        if not interaction.user.guild_permissions.administrator and interaction.user.id != OWNER_ID:
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        await interaction.response.defer(thinking=True)
        guild = interaction.guild
        type_val = restore_type.value if restore_type else "all"
        restored_ch = 0
        restored_rl = 0

        # Restore channels
        if type_val in ("all", "channels"):
            cached = await get_cached_channels(guild.id)
            existing_ids = {c.id for c in guild.channels}
            for cc in cached:
                if cc["channel_id"] in existing_ids:
                    continue
                try:
                    overwrites = {}
                    raw = json.loads(cc.get("json_overwrites", "{}"))
                    for tid, data in raw.items():
                        target = guild.get_role(int(tid))
                        if not target:
                            target = guild.get_member(int(tid))
                        if target:
                            from discord import PermissionOverwrite
                            allow = discord.Permissions(data.get("allow", 0))
                            deny = discord.Permissions(data.get("deny", 0))
                            overwrites[target] = PermissionOverwrite.from_pair(allow, deny)

                    category = guild.get_channel(cc["category_id"]) if cc["category_id"] else None
                    if cc["type"] == 0:  # text
                        await guild.create_text_channel(
                            name=cc["name"],
                            category=category,
                            position=cc["position"],
                            topic=cc.get("topic", "") or None,
                            nsfw=bool(cc.get("nsfw", 0)),
                            slowmode_delay=cc.get("slowmode", 0) or 0,
                            overwrites=overwrites,
                            reason="[Repent] Restore from cache",
                        )
                        restored_ch += 1
                    elif cc["type"] == 2:  # voice
                        await guild.create_voice_channel(
                            name=cc["name"],
                            category=category,
                            position=cc["position"],
                            overwrites=overwrites,
                            reason="[Repent] Restore from cache",
                        )
                        restored_ch += 1
                    elif cc["type"] == 4:  # category
                        await guild.create_category(
                            name=cc["name"],
                            position=cc["position"],
                            overwrites=overwrites,
                            reason="[Repent] Restore from cache",
                        )
                        restored_ch += 1
                except Exception:
                    continue

        # Restore roles
        if type_val in ("all", "roles"):
            cached = await get_cached_roles(guild.id)
            existing_ids = {r.id for r in guild.roles}
            for cr in cached:
                if cr["role_id"] in existing_ids:
                    continue
                if cr["role_id"] == guild.default_role.id:
                    continue
                try:
                    await guild.create_role(
                        name=cr["name"],
                        permissions=discord.Permissions(cr["permissions"]),
                        color=discord.Color(cr["color"]),
                        hoist=bool(cr["hoist"]),
                        mentionable=bool(cr["mentionable"]),
                        reason="[Repent] Restore from cache",
                    )
                    restored_rl += 1
                except Exception:
                    continue

        desc = []
        if restored_ch:
            desc.append(f"Restored **{restored_ch}** channel(s)")
        if restored_rl:
            desc.append(f"Restored **{restored_rl}** role(s)")
        if not desc:
            desc.append("Nothing to restore — no missing channels/roles found in cache.")
        await interaction.followup.send(
            embed=success_embed("Restore Complete", "\n".join(desc)),
            ephemeral=False,
        )

    # ── Punished Users Command ──
    @discord.app_commands.command(name="punished", description="List punished users (Admin only)")
    async def punished(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator and interaction.user.id != OWNER_ID:
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        guild = interaction.guild
        users = await get_punished_users(guild.id)
        if not users:
            return await interaction.response.send_message(
                embed=info_embed("Punished Users", "No punished users in this server."),
                ephemeral=False,
            )
        lines = []
        for u in users[:20]:
            member = guild.get_member(u["user_id"])
            name = member.mention if member else f"<@{u['user_id']}>"
            lines.append(f"{name} — `{u['punishment_type']}` — {u['reason'][:50]}")
        await interaction.response.send_message(
            embed=info_embed("Punished Users", "\n".join(lines)),
            ephemeral=False,
        )

    @discord.app_commands.command(name="pardon", description="Remove a user from the punished list (Admin only)")
    @discord.app_commands.describe(user="User to pardon")
    async def pardon(self, interaction: discord.Interaction, user: discord.User):
        if not interaction.user.guild_permissions.administrator and interaction.user.id != OWNER_ID:
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        await remove_punished_user(interaction.guild.id, user.id)
        await interaction.response.send_message(
            embed=success_embed("Pardoned", f"{user.mention} has been removed from the punished list."),
            ephemeral=False,
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(Antinuke(bot))
