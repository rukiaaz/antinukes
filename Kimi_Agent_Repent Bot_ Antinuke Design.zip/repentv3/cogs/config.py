"""
Repent - Configuration Commands
Setup wizard, whitelist management, config viewing, antinuke settings.
"""

import discord
from discord.ext import commands
from discord import app_commands

from config import OWNER_ID, DEFAULT_ANTINUKE_THRESHOLDS, PUNISHMENT_TYPES
from database import (
    get_guild, update_guild,
    get_whitelist, add_whitelist, remove_whitelist,
    get_antinuke_threshold, set_antinuke_threshold,
    get_punished_users, remove_punished_user,
    log_action,
)
from utils.embeds import success_embed, error_embed, info_embed


class Config(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _is_admin(self, interaction: discord.Interaction) -> bool:
        return (
            interaction.user.guild_permissions.administrator
            or interaction.user.id == OWNER_ID
        )

    # ── Setup Wizard ──
    @app_commands.command(name="setup", description="Interactive setup wizard (Admin only)")
    async def setup(self, interaction: discord.Interaction):
        if not await self._is_admin(interaction):
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        guild = interaction.guild
        await get_guild(guild.id)  # Ensure guild exists in DB

        embed = discord.Embed(
            title="🔧 Repent Setup Wizard",
            description=(
                "Welcome! Use the commands below to configure the bot:\n\n"
                "**1. Log Channel:**\n`/config logchannel #channel`\n\n"
                "**2. Punishment:**\n`/config punishment ban`\n\n"
                "**3. Antinuke:**\n`/antinuke enable`\n\n"
                "**4. AutoMod:**\n`/automod enable`\n\n"
                "**5. Welcome:**\n`/welcome set #channel`\n\n"
                "**6. Whitelist yourself:**\n`/whitelist add @you 2`\n\n"
                "View all settings: `/config view`"
            ),
            color=0x4488FF,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ── Config View ──
    @app_commands.command(name="config", description="View or set configuration (Admin only)")
    @app_commands.describe(
        action="view, logchannel, modchannel, punishment, threshold",
        value="Value to set",
    )
    async def config(self, interaction: discord.Interaction, action: str, value: str = None):
        if not await self._is_admin(interaction):
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        guild = interaction.guild
        settings = await get_guild(guild.id)

        if action.lower() == "view":
            whitelisted = await get_whitelist(guild.id)
            wl_count = len(whitelisted)
            embed = discord.Embed(
                title=f"⚙️ {guild.name} Configuration",
                color=0x4488FF,
            )
            log_ch = guild.get_channel(settings.get("log_channel", 0))
            mod_ch = guild.get_channel(settings.get("mod_channel", 0))
            welcome_ch = guild.get_channel(settings.get("welcome_channel", 0))
            farewell_ch = guild.get_channel(settings.get("farewell_channel", 0))
            autorole = guild.get_role(settings.get("autorole", 0))

            embed.add_field(name="Antinuke", value="✅ Enabled" if settings.get("antinuke_enabled") else "❌ Disabled", inline=True)
            embed.add_field(name="AutoMod", value="✅ Enabled" if settings.get("automod_enabled") else "❌ Disabled", inline=True)
            embed.add_field(name="Punishment", value=f"`{settings.get('punishment', 'ban')}`", inline=True)
            embed.add_field(name="Log Channel", value=log_ch.mention if log_ch else "Not set", inline=True)
            embed.add_field(name="Mod Channel", value=mod_ch.mention if mod_ch else "Not set", inline=True)
            embed.add_field(name="Welcome", value=welcome_ch.mention if welcome_ch else "Not set", inline=True)
            embed.add_field(name="Farewell", value=farewell_ch.mention if farewell_ch else "Not set", inline=True)
            embed.add_field(name="Autorole", value=autorole.mention if autorole else "Not set", inline=True)
            embed.add_field(name="Whitelisted", value=f"{wl_count} user(s)", inline=True)
            await interaction.response.send_message(embed=embed, ephemeral=False)

        elif action.lower() == "logchannel":
            ch = await self._resolve_channel(guild, value)
            if not ch:
                return await interaction.response.send_message(embed=error_embed("Channel not found."), ephemeral=True)
            await update_guild(guild.id, log_channel=ch.id)
            await interaction.response.send_message(
                embed=success_embed("Config Updated", f"Log channel set to {ch.mention}"), ephemeral=False
            )

        elif action.lower() == "modchannel":
            ch = await self._resolve_channel(guild, value)
            if not ch:
                return await interaction.response.send_message(embed=error_embed("Channel not found."), ephemeral=True)
            await update_guild(guild.id, mod_channel=ch.id)
            await interaction.response.send_message(
                embed=success_embed("Config Updated", f"Mod channel set to {ch.mention}"), ephemeral=False
            )

        elif action.lower() == "punishment":
            val = value.lower().strip()
            if val not in PUNISHMENT_TYPES:
                return await interaction.response.send_message(
                    embed=error_embed(f"Invalid punishment. Choose: {', '.join(PUNISHMENT_TYPES)}"), ephemeral=True
                )
            await update_guild(guild.id, punishment=val)
            await interaction.response.send_message(
                embed=success_embed("Config Updated", f"Punishment set to `{val}`"), ephemeral=False
            )

        elif action.lower() == "threshold":
            # /config threshold <action> <count> <seconds>
            parts = value.split()
            if len(parts) < 3:
                return await interaction.response.send_message(
                    embed=error_embed("Usage: `/config threshold <action> <count> <seconds>`\nExample: `/config threshold ban 3 10`"),
                    ephemeral=True,
                )
            action_type = parts[0]
            try:
                count = int(parts[1])
                window = int(parts[2])
            except ValueError:
                return await interaction.response.send_message(embed=error_embed("Count and seconds must be numbers."), ephemeral=True)

            await set_antinuke_threshold(guild.id, action_type, count, window)
            await interaction.response.send_message(
                embed=success_embed("Threshold Updated", f"`{action_type}`: {count} per {window}s"), ephemeral=False
            )

        else:
            await interaction.response.send_message(
                embed=error_embed("Unknown action. Use: `view`, `logchannel`, `modchannel`, `punishment`, `threshold`."),
                ephemeral=True,
            )

    # ── Antinuke Commands ──
    @app_commands.command(name="antinuke", description="Manage antinuke settings (Admin only)")
    @app_commands.describe(action="enable, disable, or status")
    async def antinuke(self, interaction: discord.Interaction, action: str):
        if not await self._is_admin(interaction):
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        guild = interaction.guild

        if action.lower() in ("enable", "on"):
            await update_guild(guild.id, antinuke_enabled=1)
            await interaction.response.send_message(
                embed=success_embed("Antinuke Enabled", "All protection modules are now active."), ephemeral=False
            )
        elif action.lower() in ("disable", "off"):
            await update_guild(guild.id, antinuke_enabled=0)
            await interaction.response.send_message(
                embed=success_embed("Antinuke Disabled", "⚠️ **Warning:** Your server is now unprotected!"), ephemeral=False
            )
        elif action.lower() == "status":
            settings = await get_guild(guild.id)
            enabled = settings.get("antinuke_enabled", 1)
            punishment = settings.get("punishment", "ban")

            embed = discord.Embed(
                title="🛡️ Antinuke Status",
                color=0x4488FF,
            )
            embed.add_field(name="Status", value="✅ Enabled" if enabled else "❌ Disabled", inline=True)
            embed.add_field(name="Punishment", value=f"`{punishment}`", inline=True)
            # Show thresholds
            lines = []
            for action_type in DEFAULT_ANTINUKE_THRESHOLDS:
                max_count, window = await get_antinuke_threshold(guild.id, action_type)
                lines.append(f"`{action_type}`: {max_count}/{window}s")
            embed.add_field(name="Thresholds", value="\n".join(lines), inline=False)
            await interaction.response.send_message(embed=embed, ephemeral=False)
        else:
            await interaction.response.send_message(
                embed=error_embed("Use: `enable`, `disable`, or `status`."), ephemeral=True
            )

    # ── Whitelist Commands ──
    @app_commands.command(name="whitelist", description="Manage whitelisted users (Admin only)")
    @app_commands.describe(
        action="add, remove, or list",
        user="User to add/remove",
        level="Trust level (1 = partial, 2 = full)",
    )
    async def whitelist(self, interaction: discord.Interaction, action: str, user: discord.Member = None, level: int = 1):
        if not await self._is_admin(interaction):
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        guild = interaction.guild

        if action.lower() == "add":
            if not user:
                return await interaction.response.send_message(embed=error_embed("Provide a user."), ephemeral=True)
            if user.id == OWNER_ID:
                return await interaction.response.send_message(
                    embed=error_embed("The bot owner is automatically whitelisted and cannot be added to the list."), ephemeral=True
                )
            level = max(1, min(2, level))
            await add_whitelist(guild.id, user.id, level, interaction.user.id)
            await log_action(guild.id, "whitelist_add", user.id, {"level": level, "added_by": interaction.user.id})
            level_name = "Full" if level == 2 else "Partial"
            await interaction.response.send_message(
                embed=success_embed("Whitelisted", f"{user.mention} added with **{level_name}** trust level."),
                ephemeral=False,
            )

        elif action.lower() == "remove":
            if not user:
                return await interaction.response.send_message(embed=error_embed("Provide a user."), ephemeral=True)
            if user.id == OWNER_ID:
                return await interaction.response.send_message(
                    embed=error_embed("Cannot remove the bot owner from the whitelist."), ephemeral=True
                )
            await remove_whitelist(guild.id, user.id)
            await log_action(guild.id, "whitelist_remove", user.id, {"removed_by": interaction.user.id})
            await interaction.response.send_message(
                embed=success_embed("Removed", f"{user.mention} removed from the whitelist."),
                ephemeral=False,
            )

        elif action.lower() == "list":
            entries = await get_whitelist(guild.id)
            if not entries:
                return await interaction.response.send_message(
                    embed=info_embed("Whitelist", "No users whitelisted."), ephemeral=False
                )
            lines = []
            for e in entries[:20]:
                member = guild.get_member(e["user_id"])
                name = member.mention if member else f"<@{e['user_id']}>"
                level_name = "Full" if e["trust_level"] == 2 else "Partial"
                lines.append(f"{name} — **{level_name}** (`{e['trust_level']}`)")
            embed = info_embed("Whitelisted Users", "\n".join(lines))
            embed.add_field(name="Note", value=f"Bot owner (`{OWNER_ID}`) is always fully whitelisted.", inline=False)
            await interaction.response.send_message(embed=embed, ephemeral=False)

        else:
            await interaction.response.send_message(
                embed=error_embed("Use: `add`, `remove`, or `list`."), ephemeral=True
            )

    # ── Punished List / Pardon ──
    @app_commands.command(name="pardon", description="Remove a user from the punished list (Admin only)")
    @app_commands.describe(user="User to pardon")
    async def pardon(self, interaction: discord.Interaction, user: discord.Member):
        if not await self._is_admin(interaction):
            return await interaction.response.send_message(embed=error_embed("Administrator required."), ephemeral=True)

        await remove_punished_user(interaction.guild.id, user.id)
        await interaction.response.send_message(
            embed=success_embed("Pardoned", f"{user.mention} has been removed from the punished list."),
            ephemeral=False,
        )

    async def _resolve_channel(self, guild: discord.Guild, value: str):
        value = value.strip()
        if value.startswith("<") and value.endswith(">"):
            value = value.strip("<#>")
        try:
            cid = int(value)
            return guild.get_channel(cid)
        except ValueError:
            for ch in guild.channels:
                if ch.name.lower() == value.lower():
                    return ch
        return None


async def setup(bot: commands.Bot):
    await bot.add_cog(Config(bot))
